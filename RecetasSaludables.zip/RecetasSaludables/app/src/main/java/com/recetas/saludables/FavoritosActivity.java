package com.recetas.saludables;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class FavoritosActivity extends AppCompatActivity {

    Button btnVerRecetas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favoritos);

        btnVerRecetas = findViewById(R.id.btnVerRecetas);

        btnVerRecetas.setOnClickListener(v -> {
            Intent intent = new Intent(FavoritosActivity.this, MainActivity.class);
            startActivity(intent);
        });

    }
}